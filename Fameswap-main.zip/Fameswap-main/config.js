// This file holds the configuration for the Supabase project.
//
// IMPORTANT: If you are using a public version control system (like GitHub),
// do not commit this file with your actual Supabase credentials. Instead, use environment variables
// or a secure vault to manage sensitive information.
const SUPABASE_CONFIG = {
  URL: "https://kzwikuxlbyhfrwxsvwpj.supabase.co", 
  ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6d2lrdXhsYnloZnJ3eHN2d3BqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM5OTgxMjAsImV4cCI6MjA2OTU3NDEyMH0.vulcEB0SjFMmy5Bcz3HdBvMW55-e5LIPjkmtTHr7pW0", 
};